/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;

/**
 *
 * @author garay
 */
public class CriaturaJurasica implements Comparable<CriaturaJurasica>, Serializable {
    private final int id;
    private final String nombre;
    private final Especie especie;
    private final int nivelPeligrosidad;
    private final int anioDescubrimiento;

    public CriaturaJurasica(int id, String nombre, Especie especie, int nivelPeligrosidad, int anioDescubrimiento) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.nivelPeligrosidad = nivelPeligrosidad;
        this.anioDescubrimiento = anioDescubrimiento;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Especie getEspecie() {
        return especie;
    }

    public int getNivelPeligrosidad() {
        return nivelPeligrosidad;
    }

    public int getAnioDescubrimiento() {
        return anioDescubrimiento;
    }

    @Override
    public String toString() {
        return "CriaturaJurasica{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", nivelPeligrosidad=" + nivelPeligrosidad + ", anioDescubrimiento=" + anioDescubrimiento + '}';
    }
    
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + nivelPeligrosidad + "," + anioDescubrimiento;
    }

    public static String getHeaderCSV() {
        return "id,nombre,especie,nivelPeligrosidad,anioDescubrimiento";
    }
     public static CriaturaJurasica fromCSV(String CriaturaCSV){ 
        String[] datos = CriaturaCSV.substring(0, CriaturaCSV.length()).split(",");
    return new CriaturaJurasica(Integer.parseInt(datos[0]),datos[1] ,Especie.valueOf(datos[2]), Integer.parseInt(datos[3]), Integer.parseInt(datos[4]) );
    }
     
    public int compareTo(CriaturaJurasica o) {
        if (this.nivelPeligrosidad != o.nivelPeligrosidad) {
            return Integer.compare(o.nivelPeligrosidad, this.nivelPeligrosidad); 
        }
        return Integer.compare(this.anioDescubrimiento, o.anioDescubrimiento); 
    } 
}
