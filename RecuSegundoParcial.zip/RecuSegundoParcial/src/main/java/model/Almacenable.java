/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package model;


import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 *
 * @author garay
 */
public interface Almacenable<T> {
   
    void agregar(T elemento);
    void eliminarSegun(Predicate<T> criterio);
    List<T> obtenerTodos();
    T buscar(Predicate<T> criterio);


    void ordenar();
    void ordenar(Comparator<T> comparador);


    List<T> filtrar(Predicate<T> criterio);
    List<T> transformar(Function<T, T> operador);
    int contar(Predicate<T> criterio);

    void guardarEnCSV(String path)throws IOException;
    void cargarDesdeCSV(String path, Function<String, T> fromCSV)throws IOException;

    void guardarEnBinario(String path) throws Exception;
    void cargarDesdeBinario(String path)throws IOException, ClassNotFoundException;

    
    void guardarEnJSON(String path)throws Exception;
}
