/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import model.Almacenable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import model.CriaturaJurasica;

public class Inventario<T> implements Almacenable<T> {
    
        private List<T> listaDeInventario;

    public Inventario() {
        listaDeInventario = new ArrayList<>();
    }

    @Override
    public void agregar(T elemento) {
        listaDeInventario.add(elemento);
    }

    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        for (int i = 0; i < listaDeInventario.size(); i++) {
            if (criterio.test(listaDeInventario.get(i))) {
                listaDeInventario.remove(i);
                i--;
            }
        }
    }

    @Override
    public List<T> obtenerTodos() {
        return listaDeInventario;
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        for (T e : listaDeInventario) {
            if (criterio.test(e)) return e;
        }
        return null;
    }

    @Override
    public void ordenar() {
        listaDeInventario.sort(null);
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        listaDeInventario.sort(comparador);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> copia = new ArrayList<>();
        for (T e : listaDeInventario) {
            if (criterio.test(e)){ 
                copia.add(e);
            }
        }
        return copia;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> copia2 = new ArrayList<>();
        for (T e : listaDeInventario) {
            copia2.add(operador.apply(e));
        }
        return copia2;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        int contador = 0;
        for (T e : listaDeInventario) {
            if (criterio.test(e)) contador++;
        }
        return contador;
    }

   @Override
    public void guardarEnCSV(String path) throws IOException {
       try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            escritor.write(CriaturaJurasica.getHeaderCSV());
            escritor.newLine();
            
           for (T obj : listaDeInventario) {
            CriaturaJurasica e = (CriaturaJurasica) obj; 
                escritor.write(e.toCSV());
                escritor.newLine();
            }
        }
        
    }
    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(ruta));
        String linea = br.readLine();
        while ((linea = br.readLine()) != null) {
            listaDeInventario.add(fromCSV.apply(linea));
        }
        br.close();
    }

    @Override
        public void guardarEnBinario(String ruta) throws Exception {
        ObjectOutputStream escritor = new ObjectOutputStream(new FileOutputStream(ruta));
        escritor.writeObject(listaDeInventario);
        escritor.close();
    }

        @Override
    public  void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
          listaDeInventario = (List<T>)  entrada.readObject();
        }
    }



    @Override
    public  void guardarEnJSON(String ruta) throws Exception {
        System.out.println("");
    }

    
}
