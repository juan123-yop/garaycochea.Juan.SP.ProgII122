/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author garay
 */
public interface RutaArchivos {
       static final String BASE = "src/main/java/resources";

    static final String FILE_CSV = "jurasico.csv";
    static final String FILE_BIN = "jurasico.bin";

    static Path getPathCSV() {
        return Paths.get(BASE, FILE_CSV);
    }

    static Path getPathBin() {
        return Paths.get(BASE, FILE_BIN);  
    }

    static String getPathString() {
        return getPathCSV().toString();
    }

    static String getPathBinString() {
        return getPathBin().toString();
    }
}
