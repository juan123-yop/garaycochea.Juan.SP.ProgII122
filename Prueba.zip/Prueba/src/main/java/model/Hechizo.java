package model;

import java.io.Serializable;
import java.util.Objects;
import model.TipoHechizo;
import percistence.CSVSerializable;

public class Hechizo implements Comparable<Hechizo>,CSVSerializable, Serializable {
    private final int id;
    private final String nombre;
    private final String creador;
    private final TipoHechizo tipo;

    public Hechizo(int id, String nombre, String creador, TipoHechizo tipo) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public TipoHechizo getTipo() {
        return tipo;
    }

    @Override
    public String toString() {
        return "Hechizo{" + "id=" + id + ", nombre=" + nombre + ", creador=" + creador + ", tipo=" + tipo + '}';
    }
     public String toCSV() {
        return id + "," + nombre + "," + creador + "," + tipo;
    }
     
    public static Hechizo fromCSV(String HechizoCSV){ 
        String[] datos = HechizoCSV.substring(0, HechizoCSV.length()).split(",");
    return new Hechizo(Integer.parseInt (datos[0]),datos[1],datos[2], TipoHechizo.valueOf(datos[3]) );
    }
    
    public static String getHeaderCSV(){
        return "id, nombre, especie, Alimentacion\n";
    }
    @Override
    public int compareTo(Hechizo h) {
      return Integer.compare(this.id, h.getId());
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + this.id;
        hash = 37 * hash + Objects.hashCode(this.nombre);
        hash = 37 * hash + Objects.hashCode(this.creador);
        hash = 37 * hash + Objects.hashCode(this.tipo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        
        if (obj == null ||  obj.getClass() != this.getClass())return false;
           
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Hechizo h = (Hechizo) obj;
            return h.getNombre().equals(this.nombre) && h.getId() == this.id && h.getCreador().equals(this.creador) && h.getTipo().equals(this.tipo);
    }

       
    

    
}
