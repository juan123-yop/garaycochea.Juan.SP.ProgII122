
package model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import percistence.CSVSerializable;


public class LibroDeHechizos<T extends CSVSerializable> {
    
        private final List<Hechizo> Hechizos;


    public LibroDeHechizos() {
        Hechizos = new ArrayList<>();
    }

    
    public void agregar(Hechizo h){
         if(h == null){
            throw new  NullPointerException("El item recivido no es valido");
        }
        Hechizos.add(h);
    }

    public Hechizo obtener(int indice) {
         if(validarPorIndice(indice) ){
           return Hechizos.get(indice);
           
        }else  throw new IndexOutOfBoundsException("el indice no es correcto");
        
    }
    
     private boolean validarPorIndice(int indice) {
        boolean toReturn = false;
        if (indice > Hechizos.size() || indice < 0) {
            toReturn = false;
        }
        return toReturn;
    }
    
    public void eliminar(int indice) {
         if (validarPorIndice(indice)) {
            Hechizos.remove(indice);
        }
    }

    public List filtrar(Predicate<Hechizo> criterio) {
       List<Hechizo> Copia = new ArrayList<>();
        for(Hechizo h : Hechizos){
            if(criterio.test(h)){
              Copia.add(h);
            }
        }
        return Copia;
    }
    
    public void paraCadaElemento(Consumer<Hechizo> accion) {
        for (Hechizo hechizo : Hechizos) {
            accion.accept(hechizo);
        }
    }
    
    public void ordenar(Comparator<Hechizo> criterio) {
         Hechizos.sort(criterio);
    }

    public void guardarEnCSV(String path) throws IOException {
        percistence.PercistenciaHechizos.guardarHechizosCSV((List<? extends Hechizo>) Hechizos, path);
    }

    public List<Hechizo> cargarDesdeCSV(String path) throws IOException {
       List<Hechizo> Hechizos = percistence.PercistenciaHechizos.cargarHechizosCSV(path);
        return Hechizos;
    }

    public void guardarEnArchivo(String path) throws IOException {
        percistence.PercistenciaHechizos.serializarHechizos((List<? extends Hechizo>) Hechizos, path);
    }

    public List<Hechizo> cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
       List<Hechizo> Hechizos = percistence.PercistenciaHechizos.deserializarHechizos(path);
        return  Hechizos;
    }    
   
}
