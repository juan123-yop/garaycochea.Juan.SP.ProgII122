package percistence;

public interface CSVSerializable {
    String toCSV();
    
}
