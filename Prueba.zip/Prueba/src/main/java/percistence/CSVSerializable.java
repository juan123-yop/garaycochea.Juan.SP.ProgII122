/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package percistence;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;

/**
 *
 * @author garay
 */
public interface CSVSerializable<T> {
    void agregar(T item);
    T obtener(int indice);
    boolean eliminar(T item);
    List<T> filtrar(Predicate<? super T> criterio);
    Iterator<T> ordenar();
    Iterator<T> ordenPersonalizado(Comparator<? super T> c);

    
}
