/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package percistence;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import model.Hechizo;

/**
 *
 * @author garay
 */
public interface PercistenciaHechizos {
      static void guardarHechizosCSV(List<? extends Hechizo> lista, String path) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            escritor.write(Hechizo.getHeaderCSV());

            for (Hechizo e : lista) {
                escritor.write(e.toCSV());
                escritor.newLine();
            }
        }
    }

    static List<Hechizo> cargarHechizosCSV(String path) throws IOException {
        List<Hechizo> toReturn = new ArrayList<>();
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            String datos;
            lector.readLine();
            while ((datos = lector.readLine()) != null) {
                toReturn.add(Hechizo.fromCSV(datos));
            }
        }
        return toReturn;
    }

    static void serializarHechizos(List<? extends Hechizo> lista, String path) throws IOException {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista);
        }
    }

    static List<Hechizo> deserializarHechizos(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            return (List<Hechizo>) entrada.readObject();
        }
    }
}
