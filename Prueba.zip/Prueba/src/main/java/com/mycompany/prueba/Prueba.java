package com.mycompany.prueba;

import java.io.IOException;
import model.TipoHechizo;
import model.Hechizo;
import model.LibroDeHechizos;
import config.RutaArchivo;

public class Prueba {

    public static void main(String[] args) {
        try {
    LibroDeHechizos<Hechizo> libro = new LibroDeHechizos<>();
    
libro.agregar(new Hechizo(1, "Expelliarmus", "Flitwick",TipoHechizo.DEFENSA));
libro.agregar(new Hechizo(2, "Alohomora", "Desconocido",TipoHechizo.UTILIDAD));
libro.agregar(new Hechizo(3, "Sectumsempra", "Severus Snape",TipoHechizo.OSCURO));
libro.agregar(new Hechizo(4, "Lumos", "Desconocido",TipoHechizo.ENCANTAMIENTO));
libro.agregar(new Hechizo(5, "Vulnera Sanentur", "Snape",TipoHechizo.CURACION));


// Mostrar todos los hechizos
System.out.println("Hechizos:");
libro.paraCadaElemento(h -> System.out.println(h));

// Filtrar por tipo DEFENSA
System.out.println("\nHechizos de tipo DEFENSA:");
libro.filtrar(h -> h.getTipo() == TipoHechizo.DEFENSA).forEach(h -> System.out.println(h));

// Filtrar por nombre que contenga "lumos"
System.out.println("\nHechizos que contienen 'lumos':");
libro.filtrar(h -> h.getNombre().contains("Lumos")).forEach(h -> System.out.println(h));

// Ordenar hechizos por ID (orden natural)
System.out.println("\nHechizos ordenados por ID:");
libro.ordenar(null);
libro.paraCadaElemento(h -> System.out.println(h));

// Ordenar hechizos por nombre
System.out.println("\nHechizos ordenados por nombre:");
libro.ordenar((p1,p2) -> p1.getNombre().compareTo(p2.getNombre()));

// Guardar en archivo binario
libro.guardarEnArchivo("src/main/java/resources/Hechizos.dat");

// Cargar desde archivo binario
LibroDeHechizos<Hechizo> libroCargado = new LibroDeHechizos<>();
libroCargado.cargarDesdeArchivo("src/main/java/resources/Hechizos.dat");
System.out.println("\nHechizos cargados desde archivo binario:");
libroCargado.paraCadaElemento(h -> System.out.println(h));

// Guardar en archivo CSV
libro.guardarEnCSV("src/main/java/resources/Hechizos.csv");

// Cargar desde archivo CSV
libroCargado.cargarDesdeCSV("src/main/java/resources/Hechizos.csv");
System.out.println("\nHechizos cargados desde archivo CSV:");
libroCargado.paraCadaElemento(h -> System.out.println(h));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
}
    }
}
