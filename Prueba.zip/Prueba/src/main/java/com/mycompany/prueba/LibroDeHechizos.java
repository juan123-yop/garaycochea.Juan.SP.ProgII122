
package com.mycompany.prueba;

import percistence.CSVSerializable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;


public class LibroDeHechizos<T extends Hechizo> implements Serializable, CSVSerializable {
    private static final long serialVersionUID = 1L;
    List<T> Hechizos = new ArrayList<>();
    @Override
    public void agregar(Object item){
         if(item == null){
            throw new  NullPointerException("El item recivido no es valido");
        }
        Hechizos.add((T)item);
    }

    @Override
    public T obtener(int indice) {
         if(indice <= 0 || indice >= tamanio() ){
            throw new IndexOutOfBoundsException("el indice no es correcto");
        }
        return Hechizos.get(indice);
    }
    
    public int tamanio(){
     return Hechizos.size();
    }
    
    @Override
    public boolean eliminar(Object item) {
        return Hechizos.remove(item);
    }

    @Override
    public List filtrar(Predicate criterio) {
       List<T> Copia = new ArrayList<>();
        for(T c : Hechizos){
            if(criterio.test(c)){
              Copia.add(c);
            }
        }
        return Copia;
    }
    public void paraCadaElemento(Consumer<? super T> accion) {
        Hechizos.forEach(accion); // [cite: 91]
    }
    @Override
    public Iterator ordenar() {
          if(!Hechizos.isEmpty() && Hechizos.get(0) instanceof Comparable){
            return ordenPersonalizado((Comparator<T>)Comparator.naturalOrder());
        }
        return Hechizos.iterator();
    }

    @Override
    public Iterator ordenPersonalizado(Comparator c) {
       List<T> copia = new ArrayList<>();
        copia.sort(c);
        return copia.iterator();
    }
    
    
    public void guardarEnArchivo( String path){
       
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
        
            escritor.write(path);
            
                System.out.println("Inventario guardado exitosamente en archivo ");
            } catch (IOException ex) {
           System.out.println(ex.getMessage());
           
        }
    }
     public void cargarDesdeArchivo(String path) throws ClassNotFoundException, FileNotFoundException, IOException{
            List<T> nuevaLista = new ArrayList<>();
            try (ObjectInputStream lector = new ObjectInputStream(new FileInputStream(path))) {
            Object obj = lector.readObject();

            // Verifica que sea realmente una lista
                if (obj instanceof List<?> list) {
                    for (Object o : list) {
                        nuevaLista.add((T) o); // se hace el cast a T
            }
        }System.out.println("Archivo cargado correctamente.");
            }
}
         public void guardarEnCSV( String path){
        
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
        
            escritor.write(Hechizo.getHeaderCSV());
            for(T h : Hechizos){
                escritor.write(h.toCSV());
                escritor.newLine();
                System.out.println(" guardado exitosamente en archivo CSV");
            }
            
            
        } catch (IOException ex) {
           System.out.println(ex.getMessage());
           
        }
        
    }
         public List<Hechizo> cargarDesdeCSV(String path, Function<String, T> constructorDesdeCSV){
        List<Hechizo> toReturn = new ArrayList<>();
        try(BufferedReader  lector =new BufferedReader(new FileReader(path))){
            
            
            String datos;
            while((datos = lector.readLine()) != null){
                toReturn.add(Hechizo.fromCSV(datos));
            }
            
     }catch (IOException ex) {
            System.out.println(ex.getMessage());
         
     }
        return toReturn;
    }
}
