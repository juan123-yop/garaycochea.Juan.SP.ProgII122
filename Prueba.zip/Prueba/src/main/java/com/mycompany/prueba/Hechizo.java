package com.mycompany.prueba;

import java.io.Serializable;
import model.TipoHechizo;

public class Hechizo implements Comparable<Hechizo>, Serializable {
    private final int id;
    private final String nombre;
    private final String creador;
    private final TipoHechizo tipo;

    public Hechizo(int id, String nombre, String creador, TipoHechizo tipo) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public TipoHechizo getTipo() {
        return tipo;
    }

    @Override
    public String toString() {
        return "Hechizo{" + "id=" + id + ", nombre=" + nombre + ", creador=" + creador + ", tipo=" + tipo + '}';
    }
     public String toCSV() {
        return id + "," + nombre + "," + creador + "," + tipo;
    }
     
    public static Hechizo fromCSV(String HechizoCSV){ 
        String[] datos = HechizoCSV.substring(0, HechizoCSV.length()).split(",");
    return new Hechizo(Integer.parseInt (datos[0]),datos[1],datos[2], TipoHechizo.valueOf(datos[3]) );
    }
    
    public static String getHeaderCSV(){
        return "id, nombre, especie, Alimentacion\n";
    }
    @Override
    public int compareTo(Hechizo o) {
      return Integer.compare(this.getId(), o.getId());
    }

    
}
