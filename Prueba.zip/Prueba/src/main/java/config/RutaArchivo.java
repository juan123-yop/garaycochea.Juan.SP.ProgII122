/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author garay
 */
public interface RutaArchivo {
     static final String BASE = "src/resources/";
    static final String FILE_CSV = "Hechizos.csv";
    static final String FILE_BIN = "Hechizos.bin";
    
    
    static Path getPathCSV(){
        return Paths.get(BASE, FILE_CSV);
    }
    
    static Path getPathBin(){
        return Paths.get(BASE, FILE_CSV);
    }
    
    static String getPathString(){
        return getPathCSV().toString();
    }
    
    static String getPathBinString(){
        return getPathBin().toString();
    }

}
